import { Routes, Route } from 'react-router-dom'
import Landing from '../pages/Landing'
import ComingSoon from '../pages/ComingSoon'

// Only the Landing Page is fully built in this pass.
// Every other route from the spec is scaffolded here so navigation
// and folder structure are ready for the next build pass.
export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<ComingSoon title="Log in" />} />
      <Route path="/register" element={<ComingSoon title="Create account" />} />
      <Route path="/forgot-password" element={<ComingSoon title="Reset password" />} />
      <Route path="/dashboard" element={<ComingSoon title="Dashboard" />} />
      <Route path="/datasets" element={<ComingSoon title="Datasets" />} />
      <Route path="/preprocessing" element={<ComingSoon title="Data preprocessing" />} />
      <Route path="/models" element={<ComingSoon title="Model training" />} />
      <Route path="/forecast" element={<ComingSoon title="Forecast dashboard" />} />
      <Route path="/comparison" element={<ComingSoon title="Model comparison" />} />
      <Route path="/products" element={<ComingSoon title="Product forecasting" />} />
      <Route path="/inventory" element={<ComingSoon title="Inventory recommendation" />} />
      <Route path="/alerts" element={<ComingSoon title="Alerts" />} />
      <Route path="/reports" element={<ComingSoon title="Reports" />} />
      <Route path="/settings" element={<ComingSoon title="Settings" />} />
      <Route path="/profile" element={<ComingSoon title="Profile" />} />
    </Routes>
  )
}
