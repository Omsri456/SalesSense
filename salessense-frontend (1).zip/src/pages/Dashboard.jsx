import DashboardLayout from '../layouts/DashboardLayout'
import KpiCard from '../components/KpiCard'
import SalesTrendChart from '../components/SalesTrendChart'
import ForecastGraphChart from '../components/ForecastGraphChart'
import RecentActivityPanel from '../components/RecentActivityPanel'
import UpcomingAlertsPanel from '../components/UpcomingAlertsPanel'
import { kpis } from '../data/dashboardData'

export default function Dashboard() {
  return (
    <DashboardLayout title="Dashboard">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {kpis.map((kpi) => (
          <KpiCard key={kpi.label} {...kpi} />
        ))}
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-2">
        <SalesTrendChart />
        <ForecastGraphChart />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <RecentActivityPanel />
        <UpcomingAlertsPanel />
      </div>
    </DashboardLayout>
  )
}
